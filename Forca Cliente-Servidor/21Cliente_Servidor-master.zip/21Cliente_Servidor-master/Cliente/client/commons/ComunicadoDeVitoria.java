package commons;

public class ComunicadoDeVitoria extends Comunicado{
}
