package commons;

public class ComunicadoDeReinicio extends Comunicado {
}
