package commons;

public class ComunicadoDeFimDeJogo extends Comunicado{
}
