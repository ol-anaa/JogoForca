package commons;

public class PedidoParaSair extends Comunicado {}
