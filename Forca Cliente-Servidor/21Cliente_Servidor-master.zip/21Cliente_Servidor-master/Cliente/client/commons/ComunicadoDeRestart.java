package commons;

public class ComunicadoDeRestart extends Comunicado
{}
