package commons;

public class PermissaoDeRodada extends Comunicado
{}
