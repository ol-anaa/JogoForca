package commons;

@SuppressWarnings("serial")
public class ComunicadoDeDesligamento extends Comunicado
{}
