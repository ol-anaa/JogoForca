package commons;

public class ComunicadoDeDerrota extends Comunicado{
}
