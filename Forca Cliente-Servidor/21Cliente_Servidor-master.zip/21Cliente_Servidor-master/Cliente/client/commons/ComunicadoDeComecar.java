package commons;

public class ComunicadoDeComecar extends Comunicado {}
