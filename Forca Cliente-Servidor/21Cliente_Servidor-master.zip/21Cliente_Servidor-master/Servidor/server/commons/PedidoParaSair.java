package commons;


import java.io.Serializable;

public class PedidoParaSair extends Comunicado {}
