package commons;

public class ComunicadoComecoDeRodada extends Comunicado{
}
