package commons;

public class PropriedadeCartas {
	final public static String[] SIMBOLOS = {"O", "E", "C", "Z"};
	final public static String[] NOMES = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "DAMA", "VAL", "REI", "AIS"};
	
	private PropriedadeCartas() {}

}
