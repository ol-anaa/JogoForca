package commons;

public class ComunicadoFinalDeRodada extends Comunicado{}
